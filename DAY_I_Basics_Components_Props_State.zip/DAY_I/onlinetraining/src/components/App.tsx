import React, { Component } from "react";
import ListOfCourses from "./listofcourses.component";
export default class App extends Component {
  render() {
    return (
      <div>
        <ListOfCourses />
      </div>
    );
  }
}
