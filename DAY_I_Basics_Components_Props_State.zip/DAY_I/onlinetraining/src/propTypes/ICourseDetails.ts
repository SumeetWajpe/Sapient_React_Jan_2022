import { CourseModel } from "../models/course.model";

export default interface ICourseDetails {
  coursedetails: CourseModel;
  DeleteACourse: (id: number) => void;
}
