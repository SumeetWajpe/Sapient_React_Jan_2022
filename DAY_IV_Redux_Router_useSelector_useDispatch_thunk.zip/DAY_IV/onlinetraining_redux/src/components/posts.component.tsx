import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { FetchPosts, FetchPostsAsync } from "../actions/actions";
import { IStoreData } from "../models/IStoreData";

export default function Posts() {
  const { posts } = useSelector((store: IStoreData) => store);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(FetchPostsAsync());
  }, []);
  return (
    <div>
      <header>
        <h2>All Posts</h2>
      </header>
      <ul className="list-group">
        {posts.map((p: any) => (
          <li className="list-group-item" key={p.id}>
            <Link to={`/postdetails/${p.id}`}>{p.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
