import React from "react";
import { useSelector } from "react-redux";
import { CourseModel } from "../models/CourseModel";
import { IStoreData } from "../models/IStoreData";

export default function CoursesWithLikes() {
  const { courses } = useSelector((store: IStoreData) => store);

  return (
    <div className="col-md-4">
      <h2>Courses with likes</h2>
      <ul className="list-group">
        {courses.map((course: CourseModel) => (
          <li key={course.id} className="list-group-item">
            {" "}
            <strong>{course.title}</strong> - {course.likes}
          </li>
        ))}
      </ul>
    </div>
  );
}
