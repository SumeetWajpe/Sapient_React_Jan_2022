import React from "react";
import { useSelector } from "react-redux";
import { CourseModel } from "../models/CourseModel";
import { IStoreData } from "../models/IStoreData";
import Course from "./course.component";

export default function ListOfCourses() {
  const { courses } = useSelector((store: IStoreData) => store);
  var coursesToBeCreated = courses.map((course: CourseModel) => (
    <Course key={course.id} coursedetails={course} />
  ));
  return (
    <div>
      <header>
        <h2>Courses Offered</h2>
      </header>
      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
}

// export default function ListOfCourses(props: any) {
//   var coursesToBeCreated = props.allCourses.map((course: CourseModel) => (
//     <Course key={course.id} coursedetails={course} {...props} />
//   ));
//   return (
//     <div>
//       <header>
//         <h2>Courses Offered</h2>
//       </header>
//       <div className="row">{coursesToBeCreated}</div>
//     </div>
//   );
// }
