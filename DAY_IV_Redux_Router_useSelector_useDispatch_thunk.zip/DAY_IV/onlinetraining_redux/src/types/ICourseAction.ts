import { CourseModel } from "../models/CourseModel";

export interface ICourseAction {
  type: string;
  courseId?: number;
  newCourse?: CourseModel;
}
