export interface IStoreData {
  courses: any;
  posts: any;
}
