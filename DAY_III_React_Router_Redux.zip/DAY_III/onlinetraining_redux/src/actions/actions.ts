import { ICourseAction } from "../types/ICourseAction";

const INCREMENT_LIKES = "INCREMENT_LIKES"; // best practise
export function IncrementLikes(): ICourseAction {
  return { type: INCREMENT_LIKES };
}
export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}
export function DeletePost() {
  return { type: "DELETE_POST" };
}
