export interface ICourseAction {
  type: string;
}
