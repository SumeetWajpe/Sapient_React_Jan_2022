import { ICourseAction } from "../types/ICourseAction";

export function courses(defStore = [], action: ICourseAction) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within courses reducer !", action);
      return defStore;
    default:
      return defStore;
  }
}
