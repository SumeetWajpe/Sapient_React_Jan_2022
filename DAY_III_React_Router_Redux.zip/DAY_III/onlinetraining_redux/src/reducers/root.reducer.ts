import { combineReducers } from "redux";
import { courses } from "./courses.reducer";
import { posts } from "./posts.reducer";
const rootReducer = combineReducers({ courses, posts });
export default rootReducer;
