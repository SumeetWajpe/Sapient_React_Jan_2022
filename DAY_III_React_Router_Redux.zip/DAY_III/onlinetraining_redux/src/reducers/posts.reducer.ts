export function posts(defStore = [], action: any) {
  switch (action.type) {
    case "DELETE_POST":
      console.log("Within posts reducer !", action);
      return defStore;
    default:
      return defStore;
  }
}
