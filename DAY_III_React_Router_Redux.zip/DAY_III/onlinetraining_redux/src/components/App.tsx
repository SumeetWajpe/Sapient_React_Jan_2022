import React from "react";

function App(props: any) {
  // console.log(props);

  return (
    <div className="App">
      <h1>Using Redux !</h1>
    </div>
  );
}

export default App;
