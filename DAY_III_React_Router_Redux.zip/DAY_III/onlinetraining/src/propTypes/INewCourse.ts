import { CourseModel } from "../models/course.model";

export interface INewCourse {
  AddANewCourse?: (newCourse: CourseModel) => void;
}
