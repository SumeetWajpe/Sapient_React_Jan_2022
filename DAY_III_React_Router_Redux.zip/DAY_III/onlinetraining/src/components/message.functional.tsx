import IMessageProps from "../propTypes/IMessage";

// 1. No render, no lifecycle methods
// 2. No state - state hook useState() 16.8 and above !

export default function MessageAsFunctional(props: IMessageProps) {
  return <h1>{props.msg}</h1>;
}
