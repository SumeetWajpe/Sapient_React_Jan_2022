import React, { Component } from "react";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import ProductCard from "./card.component";
import Counter from "./counter.functional";
import FormMessage from "./formmessage.component";
import ListOfCourses from "./listofcourses.component";
import MessageAsFunctional from "./message.functional";
import NewCourse from "./newcourse.component";
import PostDetails from "./post.details";
import PostById from "./postbyid.component";
import Posts from "./posts.component";
import PostsWithEffects from "./posts.witheffecthook";
export default class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container-fluid">
            <Link className="navbar-brand" to="/">
              Online training
            </Link>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link active" aria-current="page" to="/">
                    Courses
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/newcourse">
                    New Course
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/posts">
                    Posts
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/postbyid">
                    Post By Id
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>

        <Routes>
          <Route path="/" element={<ListOfCourses />}></Route>
          <Route path="/posts" element={<Posts />}></Route>
          <Route path="/postdetails/:id" element={<PostDetails />}></Route>
          <Route path="/postbyid" element={<PostById />}></Route>
          <Route path="/newcourse" element={<NewCourse />}></Route>
          <Route
            path="*"
            element={
              <img
                src="https://www.elegantthemes.com/blog/wp-content/uploads/2020/02/000-404.png"
                alt=""
              />
            }
          ></Route>
        </Routes>
      </BrowserRouter>
    );
  }
}

{
  /* <div> */
}
{
  /* <ListOfCourses /> */
}
{
  /* <FormMessage /> */
}
{
  /* <Posts /> */
}
{
  /* <MessageAsFunctional msg="Hello" /> */
}
{
  /* <Counter /> */
}
{
  /* <PostsWithEffects /> */
}
{
  /* <PostById /> */
}
{
  /* <ProductCard /> */
}
// </div>
