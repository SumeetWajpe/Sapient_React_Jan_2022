import React from "react";

export default function ProductCard() {
  return (
    <>
      <Card>
        <CardHeader></CardHeader>
        <CardBody></CardBody>
        <CardActions></CardActions>
      </Card>
      <hr />
      <Card>
        <CardHeader></CardHeader>
        <CardBody></CardBody>
      </Card>
      <hr />
      <Card>
        <CardBody></CardBody>
      </Card>
    </>
  );
}

export function Card(props: any) {
  return <>{props.children}</>;
}

export function CardHeader(props: any) {
  return <h2>Card Header</h2>;
}

export function CardBody(props: any) {
  return <section>Card Body !</section>;
}

export function CardActions(props: any) {
  return (
    <>
      <button className="btn btn-success">Add</button>
      <button className="btn btn-danger">Delete</button>
    </>
  );
}
