import React from "react";
import { CourseModel } from "../models/course.model";
import { INewCourse } from "../propTypes/INewCourse";
export default class NewCourse extends React.Component<
  INewCourse,
  CourseModel
> {
  constructor(props: INewCourse) {
    super(props);
    this.state = new CourseModel();
  }
  render() {
    return (
      <form className="col-md-3">
        <h2>New Course</h2>
        <label htmlFor="txtCourseId">Id : </label>
        <input
          type="number"
          id="txtCourseId"
          className="form-control"
          value={this.state.id}
          onInput={(e: any) => this.setState({ id: e.target.value })}
        />
        <label htmlFor="txtCourseName">Title : </label>
        <input
          type="text"
          id="txtCourseName"
          className="form-control"
          onInput={(e: any) => this.setState({ title: e.target.value })}
        />
        <label htmlFor="txtCoursePrice">Price : </label>
        <input
          type="number"
          id="txtCoursePrice"
          className="form-control"
          onInput={(e: any) => this.setState({ price: e.target.value })}
        />
        <label htmlFor="txtCourseLikes">Likes : </label>
        <input
          type="number"
          id="txtCourseLikes"
          className="form-control"
          onInput={(e: any) => this.setState({ likes: e.target.value })}
        />
        <label htmlFor="txtCourseRating">Rating : </label>
        <input
          type="number"
          id="txtCourseRating"
          className="form-control"
          onInput={(e: any) => this.setState({ rating: e.target.value })}
        />
        <label htmlFor="txtCourseImage">Image URL : </label>
        <input
          type="text"
          id="txtCourseImage"
          className="form-control"
          onInput={(e: any) => this.setState({ imageUrl: e.target.value })}
        />
        <button
          type="button"
          className="btn btn-success"
          onClick={() => this.props.AddANewCourse(this.state)}
        >
          Add
        </button>
      </form>
    );
  }
}
