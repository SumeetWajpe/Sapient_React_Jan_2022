import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

export default function PostDetails() {
  let { id } = useParams();
  let navigate = useNavigate();
  let [thePost, setThePost] = useState({
    id: "",
    body: "",
    title: "",
    userId: "",
  });
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts/" + id)
      .then((res) => res.json())
      .then((post) => setThePost(post));
  }, []);
  return (
    <div className="alert alert-dark my-3">
      <h2>Post Details for {id}</h2>
      <h5>User Id : {thePost.userId}</h5>
      <h5>Title : {thePost.title}</h5>
      <h5> Body : {thePost.body}</h5>

      <button className="btn btn-primary" onClick={() => navigate("/posts")}>
        Go Back{" "}
      </button>
    </div>
  );
}
