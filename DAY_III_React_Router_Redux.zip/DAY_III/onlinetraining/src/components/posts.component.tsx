import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class Posts extends Component<any, any> {
  state: Readonly<any> = { posts: [] };
  componentDidMount(): void {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => res.json())
      .then((posts) => this.setState({ posts }));
  }
  render() {
    var postsToBeCreated = this.state.posts.map((p: any) => (
      <li className="list-group-item" key={p.id}>
        <Link to={`/postdetails/${p.id}`}>{p.title}</Link>
      </li>
    ));

    var content = null;
    if (this.state.posts.length == 0) {
      content = (
        <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" />
      );
    } else {
      content = <ul className="list-group">{postsToBeCreated}</ul>;
    }
    return (
      <div>
        <header>
          <h2>All Posts</h2>
        </header>
        <main>{content}</main>
      </div>
    );
  }
}
