import { CourseModel } from "../models/course.model";

export interface ICourseState {
  courses: CourseModel[];
}
