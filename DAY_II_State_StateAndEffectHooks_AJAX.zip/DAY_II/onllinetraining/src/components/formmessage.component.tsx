import React, { Component } from "react";
import Message from "./message.component";

// controlled component
// export default class FormMessage extends Component {
//   state = { message: "" };
//   render() {
//     return (
//       <div>
//         <form>
//           <label htmlFor="txtMsg">Msg : </label>{" "}
//           <input
//             type="text"
//             id="txtMsg"
//             onChange={(e) => this.setState({ message: e.target.value })}
//           />
//           {/* <h1>{this.state.message}</h1> */}
//           <Message msg={this.state.message} />
//         </form>
//       </div>
//     );
//   }
// }

// uncontrolled component

export default class FormMessage extends Component<any> {
  input: React.RefObject<HTMLInputElement> | null;
  txtMsg: string | undefined;
  state = { txtMsg: "" };

  constructor(props: any) {
    super(props);
    this.input = React.createRef<HTMLInputElement>();
  }

  render() {
    return (
      <div>
        <form>
          <label htmlFor="txtMsg">Msg : </label>{" "}
          <input
            type="text"
            id="txtMsg"
            ref={this.input}
            onChange={() =>
              this.setState({ txtMsg: this.input?.current?.value })
            }
          />
          {/* <h1>{this.state.message}</h1> */}
          <Message msg={this.state.txtMsg} />
        </form>
      </div>
    );
  }
}
