import React, { Component } from "react";

export default class Posts extends Component<any, any> {
  state: Readonly<any> = { posts: [] };
  componentDidMount(): void {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => res.json())
      .then((posts) => this.setState({ posts }));
  }
  render() {
    var postsToBeCreated = this.state.posts.map((p: any) => (
      <li className="list-group-item" key={p.id}>
        {p.title}
      </li>
    ));
    return (
      <div>
        <header>
          <h2>All Posts</h2>
        </header>
        <main>
          <ul className="list-group">{postsToBeCreated}</ul>
        </main>
      </div>
    );
  }
}
