import React, { useState } from "react";

// export default function Counter() {
//   const [counter, setCounter] = useState(0); // destructuring !
//   return (
//     <div>
//       <p>Counter : {counter}</p>
//       <button onClick={() => setCounter(counter + 1)}>++</button>
//     </div>
//   );
// }

// export default function Counter() {
//     const [counter, setCounter] = useState({ count: 0 }); // destructuring !
//     return (
//       <div>
//         <p>Counter : {counter.count}</p>
//         <button onClick={() => setCounter({ count: counter.count + 1 })}>
//           ++
//         </button>
//       </div>
//     );
//   }

// export default function Counter() {
//   const [counter, setCounter] = useState(0); // destructuring !
//   const [age, setAge] = useState(18);
//   return (
//     <div>
//       <p>Counter : {counter}</p>
//       <button onClick={() => setCounter(counter + 1)}>++</button>
//       <hr />
//       <p>Age : {age}</p>
//       <button onClick={() => setAge(age + 1)}>++</button>
//     </div>
//   );
// }

export default function Counter() {
  const [state, setState] = useState({ count: 0, age: 18 }); // destructuring !

  return (
    <div>
      <p>Counter : {state.count}</p>
      <button onClick={() => setState({ ...state, count: state.count + 1 })}>
        ++
      </button>
      <hr />
      <p>Age : {state.age}</p>
      <button onClick={() => setState({ ...state, age: state.age + 1 })}>
        ++
      </button>
    </div>
  );
}
