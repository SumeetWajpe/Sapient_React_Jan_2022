import React, { useEffect, useState } from "react";

export default function PostsWithEffects() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => res.json())
      .then((posts) => setPosts(posts));
  }, []);
  return (
    <div>
      <header>
        <h2>All Posts</h2>
      </header>
      <ul className="list-group">
        {posts.map((p) => (
          <li className="list-group-item" key={p.id}>
            {p.title}
          </li>
        ))}
      </ul>
    </div>
  );
}
