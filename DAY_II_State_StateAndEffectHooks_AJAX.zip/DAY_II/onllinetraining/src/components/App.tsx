import React, { Component } from "react";
import Counter from "./counter.functional";
import FormMessage from "./formmessage.component";
import ListOfCourses from "./listofcourses.component";
import MessageAsFunctional from "./message.functional";
import PostById from "./postbyid.component";
import Posts from "./posts.component";
import PostsWithEffects from "./posts.witheffecthook";
export default class App extends Component {
  render() {
    return (
      <div>
        {/* <ListOfCourses /> */}
        {/* <FormMessage /> */}
        {/* <Posts /> */}
        {/* <MessageAsFunctional msg="Hello" /> */}
        {/* <Counter /> */}
        {/* <PostsWithEffects /> */}
        <PostById />
      </div>
    );
  }
}
