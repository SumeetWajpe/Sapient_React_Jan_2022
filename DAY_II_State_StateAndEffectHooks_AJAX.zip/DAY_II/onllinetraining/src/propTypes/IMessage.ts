export default interface IMessageProps {
  msg: string;
}
