import React, { useState, useEffect } from "react";

export default function PostById() {
  const [postId, setPostId] = useState(1);
  const [post, setPost] = useState({ title: "" });
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts/" + postId)
      .then((res) => res.json())
      .then((post) => setPost(post));
  }, [postId]);
  return (
    <div>
      <label htmlFor="txtPostId">Enter Post Id : </label>{" "}
      <input
        type="text"
        id="txtPostId"
        value={postId}
        onChange={(e: any) => setPostId(e.target.value)}
      />
      <p>
        <strong>{post.title}</strong>
      </p>
    </div>
  );
}
