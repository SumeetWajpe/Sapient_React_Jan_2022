import React, { Component, useContext } from "react";
let CounterContext = React.createContext({
  count: 0,
  incrementCount: () => {},
});

export class GlobalData extends Component {
  state: Readonly<any> = { counter: 1000 };

  render() {
    return (
      <CounterContext.Provider
        value={{
          count: this.state.counter,
          incrementCount: () =>
            this.setState({ counter: this.state.counter + 1 }),
        }}
      >
        {this.props.children}
      </CounterContext.Provider>
    );
  }
}

export class GrandParent extends Component {
  render() {
    return (
      <div style={{ border: "2px solid blue" }}>
        <GlobalData>
          <h1>Grand Parent</h1>
          <Parent />
        </GlobalData>
      </div>
    );
  }
}

export class Parent extends Component {
  render() {
    return (
      <div style={{ border: "2px solid red" }}>
        <h2>Parent</h2>
        <Child />
        <YetAnotherChild />
        {/* <AnotherChild /> */}
      </div>
      // <>
      //   <CounterContext.Provider value={{ count: 500 }}>
      //     <h2>Parent</h2>
      //     <Child />
      //   </CounterContext.Provider>
      // </>
    );
  }
}

// export class Child extends Component {
//   render() {
//     return (
//       <>
//         <CounterContext.Consumer>
//           {(ctx) => (
//             <div>
//               <h3>Child</h3>
//               <strong>{ctx.count}</strong>
//             </div>
//           )}
//         </CounterContext.Consumer>
//       </>
//     );
//   }
// }

export class Child extends Component {
  static contextType = CounterContext; // only works with class based components
  render() {
    return (
      <div style={{ border: "2px solid green" }}>
        <h3>Child</h3>
        <strong>{this.context.count}</strong> {"  "}
        <button
          className="btn btn-primary"
          onClick={() => this.context.incrementCount()}
        >
          ++
        </button>
      </div>
    );
  }
}

// export class AnotherChild extends Component {
//   static contextType = CounterContext; // only works with class based components
//   render() {
//     return (
//       <div style={{ border: "2px solid orange" }}>
//         <h3>Another Child</h3>
//         <strong>{this.context.count}</strong>
//       </div>
//     );
//   }
// }

export function YetAnotherChild() {
  const ctx = useContext(CounterContext);
  return (
    <div style={{ border: "2px solid black" }}>
      <h3>Yet Another Child !</h3>
      <strong>{ctx.count}</strong>
    </div>
  );
}
