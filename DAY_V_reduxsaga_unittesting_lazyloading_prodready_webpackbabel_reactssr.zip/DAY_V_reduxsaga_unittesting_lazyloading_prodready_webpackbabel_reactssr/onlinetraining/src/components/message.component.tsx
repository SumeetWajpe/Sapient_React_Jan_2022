import React, { Component } from "react";

export default class Message extends Component<any> {
  render() {
    console.log("Render :: Message !");

    return <h1>{this.props.msg}</h1>;
  }
}
