import { Add, Point } from "./module";

console.log(`Addition is : ${Add(20, 30)}`);
let point = new Point();
point.x = 20;
point.y = 30;
