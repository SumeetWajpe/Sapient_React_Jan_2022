export class Point {
  constructor() {
    this.x = 100;
    this.y = 10;
  }
}

export const Add = (x, y) => x + y;
