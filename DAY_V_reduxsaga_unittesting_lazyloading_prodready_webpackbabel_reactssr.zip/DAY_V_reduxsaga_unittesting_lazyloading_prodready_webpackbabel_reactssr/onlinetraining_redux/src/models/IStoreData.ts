import { CourseModel } from "./CourseModel";

export interface IStoreData {
  courses: any;
  posts: any;
}
