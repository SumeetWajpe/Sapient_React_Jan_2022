export function posts(defStore = [], action: any) {
  switch (action.type) {
    case "DELETE_POST":
      console.log("Within posts reducer !", action);
      console.log(defStore);

      return defStore;
    case "FETCH_POSTS":
      return action.posts;
    default:
      return defStore;
  }
}
