import { CourseModel } from "../models/CourseModel";
import { ICourseAction } from "../types/ICourseAction";
// let courseId: number, index: number;

export function courses(defStore: CourseModel[] = [], action: ICourseAction) {
  let courseId = action.courseId;
  let index = defStore.findIndex((c: CourseModel) => c.id === courseId);
  switch (action.type) {
    case "INCREMENT_LIKES":
      return [
        ...defStore.slice(0, index),
        { ...defStore[index], likes: defStore[index].likes + 1 },
        ...defStore.slice(index + 1),
      ];
    case "DELETE_COURSE":
      return [...defStore.slice(0, index), ...defStore.slice(index + 1)]; // use filter
    case "ADD_NEW_COURSE":
      return [...defStore, action.newCourse];
    default:
      return defStore;
  }
}
