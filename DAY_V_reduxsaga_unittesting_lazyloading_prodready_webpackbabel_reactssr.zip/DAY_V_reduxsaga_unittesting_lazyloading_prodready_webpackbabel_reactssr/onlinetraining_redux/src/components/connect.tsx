import { connect } from "react-redux";
import { IStoreData } from "../models/IStoreData";
import * as allActions from "../actions/actions";
import { bindActionCreators } from "redux";
import App from "./App";

//to expose store data as props to react component
function mapStateToProps(store: IStoreData) {
  return {
    allCourses: store.courses, // in component => props.allCourses
    allPosts: store.posts,
  };
}

// to expose actions as props to react component
function mapDispatchToProps(dispatch: any) {
  return bindActionCreators(allActions, dispatch);
}
// a HOC
let MainApp = connect(mapStateToProps, mapDispatchToProps)(App);
export default MainApp;
