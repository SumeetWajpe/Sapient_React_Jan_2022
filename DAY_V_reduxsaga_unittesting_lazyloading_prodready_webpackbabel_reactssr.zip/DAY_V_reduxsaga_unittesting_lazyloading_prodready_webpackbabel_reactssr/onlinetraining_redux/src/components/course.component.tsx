import React from "react";
import { useDispatch } from "react-redux";
import { DeleteCourse, IncrementLikes } from "../actions/actions";

export default function Course(props: any) {
  const dispatch = useDispatch();
  let ratings = [];
  for (let index = 0; index < props.coursedetails.rating; index++) {
    ratings.push(
      <i
        key={index}
        className="bi bi-star-fill"
        style={{ color: "orange" }}
      ></i>
    );
  }
  return (
    <div className="col-md-3">
      <div className="card m-2">
        <img
          src={props.coursedetails.imageUrl}
          height="150px"
          className="card-img-top"
          alt={props.coursedetails.title}
        />
        <div className="card-body">
          {ratings}
          <h5 className="card-title">{props.coursedetails.title}</h5>
          <p className="card-text"> ₹. {props.coursedetails.price}</p>
          <button
            className="btn btn-primary"
            onClick={() => dispatch(IncrementLikes(props.coursedetails.id))}
          >
            <i className="bi bi-hand-thumbs-up-fill"></i>{" "}
            {props.coursedetails.likes}
          </button>

          <button
            className="btn btn-danger mx-1"
            onClick={() => dispatch(DeleteCourse(props.coursedetails.id))}
          >
            <i className="bi bi-trash-fill"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
