import React from "react";
import CoursesWithLikes from "./courseswithlikes.component";
import ListOfCourses from "./listofcourses.component";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import Posts from "./posts.component";
import NewCourse from "./newcourse.component";
import PostDetails from "./post.details";

function App(props: any) {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Online training
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/">
                  Courses
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="page"
                  to="/courseswithlikes"
                >
                  Courses With Likes
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/newcourse">
                  New Course
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/posts">
                  Posts
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<ListOfCourses />}></Route>
        <Route path="/courseswithlikes" element={<CoursesWithLikes />}></Route>

        <Route path="/posts" element={<Posts />}></Route>
        <Route path="/postdetails/:id" element={<PostDetails />}></Route>
        <Route path="/newcourse" element={<NewCourse />}></Route>
        <Route
          path="*"
          element={
            <img
              src="https://www.elegantthemes.com/blog/wp-content/uploads/2020/02/000-404.png"
              alt=""
            />
          }
        ></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;

// function App(props: any) {
//   return (
//     <div>
//       <CoursesWithLikes {...props} />
//       <ListOfCourses {...props} />
//     </div>
//   );
// }
