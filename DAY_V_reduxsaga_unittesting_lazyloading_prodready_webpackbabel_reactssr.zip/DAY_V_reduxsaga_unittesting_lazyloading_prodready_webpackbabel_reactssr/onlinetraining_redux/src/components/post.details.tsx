import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { IStoreData } from "../models/IStoreData";

export default function PostDetails() {
  const { posts } = useSelector((store: IStoreData) => store);

  let { id } = useParams();
  let navigate = useNavigate();
  let thePost = posts.find((p: any) => p.id == id);
  console.log(posts);

  return (
    <div className="alert alert-dark my-3">
      <h2>Post Details for {id}</h2>
      <h5>User Id : {thePost.userId}</h5>
      <h5>Title : {thePost.title}</h5>
      <h5> Body : {thePost.body}</h5>

      <button className="btn btn-primary" onClick={() => navigate("/posts")}>
        Go Back{" "}
      </button>
    </div>
  );
}
