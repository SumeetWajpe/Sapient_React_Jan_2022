import axios from "axios";
import { call, put, retry, takeEvery } from "redux-saga/effects";

interface IPost {
  id: number;
  userId: number;
  title: string;
  body: string;
}

interface Response {
  config: any;
  data: any;
  headers: any;
  request: any;
  status: number;
  statusText: string;
}

let getPosts = () =>
  axios.get<IPost[]>("https://jsonplaceholder.typicode.com/posts");

function* fetchPostsFromAPI() {
  try {
    const response: Response = yield call(getPosts);
    yield put({ type: "FETCH_POSTS", posts: response.data });
  } catch (error) {}
}

function* fetchPostsFromAPIWithRetry() {
  try {
    let duration = 1000;
    let response: Response = yield retry(3, duration * 10, getPosts);
    yield put({ type: "FETCH_POSTS", posts: response.data });
  } catch (error) {}
}

export function* mySaga() {
  //   yield takeEvery("FETCH_POSTS_ASYNC", fetchPostsFromAPI);
  yield takeEvery("FETCH_POSTS_ASYNC", fetchPostsFromAPIWithRetry);
}
