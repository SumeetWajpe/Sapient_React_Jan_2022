import { CourseModel } from "../models/CourseModel";
import { ICourseAction } from "../types/ICourseAction";

const INCREMENT_LIKES = "INCREMENT_LIKES"; // best practise
export function IncrementLikes(courseId: number) {
  return { type: INCREMENT_LIKES, courseId };
}
export function DeleteCourse(courseId: number) {
  return { type: "DELETE_COURSE", courseId };
}
export function DeletePost() {
  return { type: "DELETE_POST" };
}

export function AddNewCourse(newCourse: CourseModel) {
  return { type: "ADD_NEW_COURSE", newCourse };
}

export function FetchPosts(posts: any) {
  return { type: "FETCH_POSTS", posts };
}

export function FetchPostsError(err: any) {
  return { type: "FETCH_POSTS_ERROR", err };
}
// using redux-thunk
// export function FetchPostsAsync() {
//   return (dispatch: any) => {
//     fetch("https://jsonplaceholder.typicode.com/posts")
//       .then((res) => res.json())
//       .then((posts) => dispatch(FetchPosts(posts)))
//       .catch((err) => dispatch(FetchPostsError(err)));
//   };
// }

export function FetchPostsAsync() {
  return { type: "FETCH_POSTS_ASYNC" };
}
